fruits='apple banana cherry'.split(' ')
print(fruits)
print('apple' in fruits)
print('coconut' in fruits)