input_txt = open('exp.txt','r')
line=input_txt.readline()
print(line)
while line !='':
    print(line)
    line=input_txt.readline()
input_txt.close()
print('申英君SHEN YINGJUN신영군')
