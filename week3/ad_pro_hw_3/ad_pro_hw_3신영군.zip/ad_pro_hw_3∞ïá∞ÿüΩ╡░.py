print('hello world')

name='申英君신영군'
print(name)

print('my name is ',name,'.')
print('my name is '+name+'.')
print('my name is %s'%name)
print(f'my name is {name}.')

first_name='SHEN'
last_name='YINGJUN'
profession='student'
affiliation='Yonsei University'
print('Hello %s %s, you a %s at %s.'
      %(first_name,last_name,profession,affiliation))
print(f'Hello, {first_name} {last_name}, You are a {profession} in {affiliation}.') 