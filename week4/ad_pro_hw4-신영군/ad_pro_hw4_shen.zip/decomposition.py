import os

fname='D:/sampledir/random.txt'
print(f'filename:{fname}')
print(f'dirname:{os.path.dirname(fname)}')
print(f'dirname:{os.path.dirname(fname)}')