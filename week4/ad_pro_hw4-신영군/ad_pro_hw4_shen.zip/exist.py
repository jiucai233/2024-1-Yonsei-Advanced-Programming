import os

print(os.path.exists('emails'))
print(os.path.exists('email'))
print(os.path.exists('emails/jiucai233.txt'))
print(os.path.exists('sampledir/join.py'))