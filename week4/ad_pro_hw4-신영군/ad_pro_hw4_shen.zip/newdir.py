import os

os.mkdir('sampledir')
os.makedirs('sampledir',exist_ok=True)